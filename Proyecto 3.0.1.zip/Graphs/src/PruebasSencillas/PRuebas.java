package PruebasSencillas;

import java.util.Comparator;
import java.util.PriorityQueue;

import Graph.Grafo;

/**
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 * ESTA NO TIENE NADA IMPORTANTE :D.
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 * @author usuario
 *
 */
public class PRuebas {

	public static Grafo<Integer> G;
	public static int[] A = { 0, 1, 2, 3, 4 };
	public static int[] PESOS = { 5, 2, 11, 4, 4, 8, 2, 1, 5, 6 };

	public static void main(String[] args) {
		G = new Grafo<>();
		for (int i = 0; i < A.length; i++) {
			G.agregarVertice(A[i]);
		}
		G.agregarND(A[0], A[1], PESOS[0]);
		G.agregarND(A[0], A[2], PESOS[1]);
		G.agregarND(A[1], A[4], PESOS[2]);
		G.agregarND(A[2], A[3], PESOS[3]);

		// TODO Auto-generated method stub
	}
}