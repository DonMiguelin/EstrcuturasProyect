package PruebasSencillas;

import java.util.PriorityQueue;
import java.util.Queue;

import javax.management.Query;

import GrahpMatrix.MatrizAdyacencia;

public class PruebasMatrices {

	public static MatrizAdyacencia<Integer> matrix;
	public static int[] A = { 0, 1, 2, 3, 4 };
	public static int[] PESOS = { 5, 2, 6, 4, 1, 3 };

	public static void main(String[] args) {
		matrix = new MatrizAdyacencia<>(A.length);
		for (int i = 0; i < A.length; i++) {
			matrix.agregarVertice(A[i]);
		}
		System.out.println(matrix.getCantidadNodos() + "\n");
		matrix.agregarND(A[0], A[1], PESOS[0]);
		matrix.agregarND(A[0], A[2], PESOS[1]);
		matrix.agregarND(A[1], A[3], PESOS[2]);
//		matrix.agregarND(A[1], A[4], PESOS[4]);
		matrix.agregarND(A[2], A[3], PESOS[3]);
//		matrix.agregarND(A[3], A[4], PESOS[5]);
		int[][] N = matrix.getOtros().FloydWarshall(matrix);

		int rows = N.length;
		int columns = N[0].length;
		String str = "|\t";
		for (int i = 0; i < rows; i++) {
			for (int j = 0; j < columns; j++) {
				str += N[i][j] + "\t";
			}

			System.out.println(str + "|");
			str = "|\t";
		}
	}

}
