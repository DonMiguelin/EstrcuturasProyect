import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.PriorityQueue;
import java.util.Queue;

public class MainFW1 {
	private static MatrizAdyacencia<Integer> G;
	private static int p1;
	private static int p2;
	private static int[] policias;
	private static int[] bancos;
	private static HashMap<Integer, Queue<Integer>> pesos;

	public static void main(String[] args) throws IOException {
		BufferedReader lector = new BufferedReader(new InputStreamReader(System.in));
		BufferedWriter escritor = new BufferedWriter(new OutputStreamWriter(System.out));
		String linea = lector.readLine();
		while (linea.split(" ").length == 4) {
			String[] datos = linea.split(" ");
			int[] data = new int[datos.length];
			for (int i = 0; i < datos.length; i++) {
				data[i] = Integer.parseInt(datos[i]);
			}
			int N = data[0];
			int M = data[1];
			int B = data[2];
			int P = data[3];
			G = new MatrizAdyacencia<>(N);
			bancos = new int[B];
			policias = new int[P];
			for (int i = 1; i <= M; i++) {
				linea = lector.readLine();
				String[] v = linea.split(" ");
				int vInicial = Integer.parseInt(v[0]);
				int vFinal = Integer.parseInt(v[1]);
				int peso = Integer.parseInt(v[2]);
				G.agregarVertice(vInicial);
				G.agregarVertice(vFinal);
				G.agregarND(vInicial, vFinal, peso);
			}
			linea = lector.readLine();
			String[] l = linea.split(" ");
			for (int i = 0; i < B; i++) {
				bancos[i] = Integer.parseInt(l[i]);
				G.agregarVertice(bancos[i]);
			}
			if (P != 0) {
				linea = lector.readLine();
				String[] p = linea.split(" ");
				for (int i = 0; i < P; i++) {
					policias[i] = Integer.parseInt(p[i]);
					G.agregarVertice(policias[i]);
				}
				// respuesta.
				caminoMasCorto(G, bancos, policias, escritor);
			}
			G = null;
			if (lector.ready()) {
				linea = lector.readLine();
			}

		}
		escritor.close();
	}

	private static String bancosFinales(int[] bancos, int[] policias, MatrizAdyacencia<Integer> g) {
		int[][] Emergente = g.getOtros().FloydWarshall(g);
		distanciasBancosPolicias(Emergente);
		String listaDebancos = "";
		int p3, p4;
		String m = "";
		m = maximoYminimo(pesos, bancos[0]);
		int pos = 0;
		p1 = Integer.parseInt(m.split(" ")[0]);// maximo
		p2 = Integer.parseInt(m.split(" ")[1]);// minimo
		for (int i = 0; i < bancos.length - 1; i++) {
			m = maximoYminimo(pesos, bancos[i + 1]);
			p3 = Integer.parseInt(m.split(" ")[0]);// maximo
			p4 = Integer.parseInt(m.split(" ")[1]);// minimo
			if (p2 == p4 && p3 == p1) {
				if (!listaDebancos.contains("" + bancos[pos])) {
					listaDebancos += bancos[i] + " ";
					pos++;
				}
				if (!listaDebancos.contains("" + bancos[i + 1])) {
					listaDebancos += bancos[i + 1] + " ";
				}
			} else {
				if (p1 == p3) {
					if (p2 < p4) {
						p2 = p4;
						if (!listaDebancos.contains("" + bancos[i + 1])) {
							listaDebancos = bancos[i + 1] + " ";
							pos++;

						}
					} else {
						if (!listaDebancos.contains("" + bancos[pos])) {
							listaDebancos = bancos[pos] + " ";
						}

					}

				} else {
					if (p1 < p3) {
						p1 = p3;
						p2 = p4;
						if (!listaDebancos.contains("" + bancos[i + 1])) {
							listaDebancos = bancos[i + 1] + " ";
							pos++;
						}
					} else {
						if (!listaDebancos.contains("" + bancos[pos]))
							listaDebancos = bancos[pos] + " ";
					}
				}
			}
		}

		return listaDebancos;
	}

	public static void caminoMasCorto(MatrizAdyacencia<Integer> g, int[] bancos, int[] policias,
			BufferedWriter escritor) throws IOException {
		g = G;
		String[] A = bancosFinales(bancos, policias, g).split(" ");
		Arrays.sort(A);
		String b = "";
		for (int i = 0; i < A.length; i++) {
			if (i == A.length - 1) {
				b += A[i] + "";
			} else
				b += A[i] + " ";
		}
		int respuesta = p2;
		if (respuesta != Integer.MAX_VALUE) {
			escritor.write(A.length + " " + respuesta);
			escritor.newLine();
			escritor.write(b);
			escritor.newLine();
			escritor.flush();

		} else {
			escritor.write(A.length + " " + "*");
			escritor.newLine();
			escritor.write(b);
			escritor.newLine();
			escritor.flush();
		}
	}

	private static void distanciasBancosPolicias(int[][] matriz) {
		pesos = new HashMap<>();
		for (int i = 0; i < bancos.length; i++) {
			Queue<Integer> priori = new PriorityQueue<>();
			for (int j = 0; j < policias.length; j++) {
				priori.add(matriz[G.getElementos().get(bancos[i])][G.getElementos().get(policias[j])]);
			}
			pesos.put(bancos[i], priori);
		}
	}

	private static String maximoYminimo(HashMap<Integer, Queue<Integer>> distancias, int banco) {
		String maxmin = "";
		Queue<Integer> distance = distancias.get(banco);
		int max, min;
		min = distance.peek();
		max = min;
		max = (int) distance.toArray()[distance.size() - 1];
		maxmin = max + " " + min;
		return maxmin;

	}

	public static class Adyacencia<T> {
		protected T adyacente;
		protected int ponderacion;

		public Adyacencia(T ady, int p) {
			adyacente = ady;
			ponderacion = p;
		}

		public T getAdyacente() {
			return adyacente;
		}

		public void setAdyacente(T adyacente) {
			this.adyacente = adyacente;
		}

		public int getPonderacion() {
			return ponderacion;
		}

		public void setPonderacion(int ponderacion) {
			this.ponderacion = ponderacion;
		}

	}

	public static class HerramientasGrafo<T> implements IHerramientasGrafo<T> {
		private int V;

		@Override
		public void recorridoAmplitud(MatrizAdyacencia<T> G, Nodo<T> ref) {
			// TODO Auto-generated method stub

		}

		@Override
		public void recorridoProfundidad(MatrizAdyacencia<T> G, Nodo<T> ref) {
			// TODO Auto-generated method stub

		}

		@Override
		public int[] DijkstraMatriz(MatrizAdyacencia<T> G, int ref) {
			int[][] Matrix = G.darMAtrizAdyacencia();
			V = Matrix.length;
			return Dijkstra(Matrix, ref, V);
		}

		private int[] Dijkstra(int graph[][], int src, int v1) {
			V = v1;
			int dist[] = new int[V]; // Matriz de distancias.
			Boolean sptSet[] = new Boolean[V]; // Matriz que indica si los nodos
												// ya
												// fueron visitados.
			for (int i = 0; i < V; i++) {
				dist[i] = Integer.MAX_VALUE;
				sptSet[i] = false;
				// La distancia de los nodos cambia a infinito y visitado inicia
				// en
				// false.
			}

			// Distancia desde el nodo actual.
			dist[src] = 0;

			// Encuentra la minima distancia de los vertices.
			for (int count = 0; count < V - 1; count++) {
				int u = minimaDistancia(dist, sptSet, V); // se toma la
															// distancia
															// del
															// nodo actual a los
															// dem�s.
				sptSet[u] = true; // el nodo se marca como visitado
				for (int v = 0; v < V; v++)
					// La distancia del nodo actual a los adyacentes cambia.
					if (!sptSet[v] && graph[u][v] != 0 && dist[u] != Integer.MAX_VALUE
							&& dist[u] + graph[u][v] < dist[v])
						dist[v] = dist[u] + graph[u][v];
			}

			// Devuelve el arreglo con las distancias m�s cortas.
			return dist;
		}

		private int minimaDistancia(int dist[], Boolean sptSet[], int v1) {
			V = v1;
			int min = Integer.MAX_VALUE, min_index = -1;

			for (int v = 0; v < V; v++)
				if (sptSet[v] == false && dist[v] <= min) {
					min = dist[v];
					min_index = v;
				}

			return min_index;
		}

		@Override
		public int[][] FloydWarshall(MatrizAdyacencia<T> G) {
			// TODO Auto-generated method stub
			int INFINITO = Integer.MAX_VALUE;
			int[][] Distancias = new int[G.darCantidadNodos()][G.darCantidadNodos()];
			int i, j, k;
			for (i = 0; i < G.darCantidadNodos(); i++) {
				for (j = 0; j < G.darCantidadNodos(); j++) {
					Distancias[i][j] = G.darMAtrizAdyacencia()[i][j];
					if ((i != j) && G.darMAtrizAdyacencia()[i][j] == 0)
						Distancias[i][j] = INFINITO;
				}
			}
			for (k = 0; k < G.darCantidadNodos(); k++) {
				for (i = 0; i < G.darCantidadNodos(); i++) {
					for (j = 0; j < G.darCantidadNodos(); j++) {
						if (Distancias[i][k] != INFINITO && Distancias[k][j] != INFINITO
								&& Distancias[i][k] + Distancias[k][j] < Distancias[i][j])
							Distancias[i][j] = Distancias[i][k] + Distancias[k][j];
					}

				}
			}

			return Distancias;
		}
	}

	public interface IHerramientasGrafo<T> {

		public int[] DijkstraMatriz(MatrizAdyacencia<T> G, int ref);

		public void recorridoAmplitud(MatrizAdyacencia<T> G, Nodo<T> ref);

		public void recorridoProfundidad(MatrizAdyacencia<T> G, Nodo<T> ref);

		public int[][] FloydWarshall(MatrizAdyacencia<T> G);
	}

	public interface ILista<T> {

		public boolean agregar(T elem);

		public boolean asignar(int pos, T elem) throws Exception;

		public boolean eliminar(T elem) throws Exception;

		public T eliminar(int pos) throws Exception;

		public int longitud();

		public boolean estaElemento(T elem);

		public int buscar(T elem) throws Exception;

		public T obtenerElemento(int pos);

		public boolean estaVacia();

		public boolean eliminarTodos();

	}

	public interface IMatriz<T> {

		public void agregarND(T vInicial, T vFinal, int peso);

		public void eliminarArista(T uno, T dos);

		public int[][] darMAtrizAdyacencia();

	}

	public static class ListaArreglo<T> implements ILista<T> {

		protected ArrayList<T> contenedora;

		public ListaArreglo() {
			contenedora = new ArrayList<T>();
		}

		public boolean agregar(T elem) {
			boolean agregado = false;
			if (!contenedora.contains(elem)) {
				contenedora.add(elem);
				agregado = true;
			}
			return agregado;
		}

		public boolean agregarEnPos(int pos, T elem) {
			boolean agregado = false;
			if (!contenedora.contains(elem)) {
				contenedora.add(pos, elem);
				agregado = true;
			}
			return agregado;
		}

		@Override
		public boolean asignar(int pos, T elem) {
			if (!(pos > contenedora.size())) {
				contenedora.set(pos, elem);
				return true;
			} else {
				return false;
			}
		}

		public boolean eliminar(T elem) throws Exception {
			if (!contenedora.contains(elem)) {
				throw new Exception("No existe: " + elem);
			} else {
				contenedora.remove(buscar(elem));
			}
			return true;
		}

		@Override
		public T eliminar(int pos) throws Exception {
			T elemento = null;
			if (pos >= contenedora.size()) {
				throw new Exception("No existe: " + pos);
			} else {
				elemento = contenedora.remove(pos);
			}
			return elemento;
		}

		@Override
		public int longitud() {
			return contenedora.size();
		}

		@Override
		public boolean estaElemento(T elem) {
			return contenedora.contains(elem);
		}

		@Override
		public int buscar(T elem) throws Exception {
			int con = 0;
			boolean ya = false;
			if (!contenedora.contains(elem)) {
				throw new Exception("No existe: " + elem);
			} else {
				for (int i = 0; i < contenedora.size() && ya == false; i++) {
					if (elem.equals(contenedora.get(i))) {
						con = i;
						ya = true;
					}
				}
			}
			return con;
		}

		@Override
		public T obtenerElemento(int pos) {
			return contenedora.get(pos);
		}

		@Override
		public boolean estaVacia() {
			return contenedora.isEmpty();
		}

		@Override
		public boolean eliminarTodos() {
			contenedora.clear();
			return true;
		}
	}

	public static class MatrizAdyacencia<T> implements IMatriz<T> {

		private HerramientasGrafo<T> otros;
		private int[][] adyacencias;
		private Hashtable<T, Nodo<T>> vertices;
		private Hashtable<T, Integer> elementos;
		private int cantidadNodos;
		private int tamanioMatriz;

		public MatrizAdyacencia(int tamanho) {
			otros = new HerramientasGrafo<>();
			tamanioMatriz = tamanho;
			adyacencias = new int[tamanioMatriz][tamanioMatriz];
			vertices = new Hashtable<>();
			elementos = new Hashtable<>();
		}

		public void agregarVertice(T nuevo1) {
			Nodo<T> nuevo = new Nodo<T>(nuevo1);
			if (!elementos.containsKey(nuevo1)) {
				elementos.put(nuevo1, cantidadNodos);
				vertices.put(nuevo1, nuevo);
				cantidadNodos++;
			}

		}

		public int darCantidadNodos() {
			return cantidadNodos;
		}

		@Override
		public int[][] darMAtrizAdyacencia() {
			for (Iterator<T> iterator = elementos.keySet().iterator(); iterator.hasNext();) {
				T type = (T) iterator.next();
				ListaArreglo<Adyacencia<T>> nodosAdyacentes = vertices.get(type).getAdyacentes();
				for (int j = 0; j < nodosAdyacentes.longitud(); j++) {
					int peso = nodosAdyacentes.obtenerElemento(j).getPonderacion();
					adyacencias[elementos.get(type)][elementos
							.get(nodosAdyacentes.obtenerElemento(j).getAdyacente())] = peso;
				}

			}
			return adyacencias;
		}

		@Override
		public void agregarND(T vInicial, T vFinal, int peso) {
			// TODO Auto-generated method stub
			vertices.get(vInicial).agregarAdyacente(vFinal, peso);
			vertices.get(vFinal).agregarAdyacente(vInicial, peso);
		}

		@Override
		public void eliminarArista(T uno, T dos) {
			// TODO Auto-generated method stub
			try {
				vertices.get(uno).eliminarAdyacencia(vertices.get(uno).darPosicionAdyacente(dos));
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			try {
				vertices.get(dos).eliminarAdyacencia(vertices.get(dos).darPosicionAdyacente(uno));
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}

		public HerramientasGrafo<T> getOtros() {
			return otros;
		}

		public void setOtros(HerramientasGrafo<T> otros) {
			this.otros = otros;
		}

		public Hashtable<T, Integer> getElementos() {
			return elementos;
		}

		public void setElementos(Hashtable<T, Integer> elementos) {
			this.elementos = elementos;
		}

		public int[][] getAdyacencias() {
			return adyacencias;
		}

		public void setAdyacencias(int[][] adyacencias) {
			this.adyacencias = adyacencias;
		}

		public Hashtable<T, Nodo<T>> getVertices() {
			return vertices;
		}

		public void setVertices(Hashtable<T, Nodo<T>> vertices) {
			this.vertices = vertices;
		}

		public int getCantidadNodos() {
			return cantidadNodos;
		}

		public void setCantidadNodos(int cantidadNodos) {
			this.cantidadNodos = cantidadNodos;
		}

		public int getTamanioMatriz() {
			return tamanioMatriz;
		}

		public void setTamanioMatriz(int tamanioMatriz) {
			this.tamanioMatriz = tamanioMatriz;
		}
	}

	public static class Nodo<T> {
		public final static int INFINITO = Integer.MAX_VALUE;
		protected T element;
		protected int distancia;
		protected int cantidadDeAdyacencias;
		protected ListaArreglo<Adyacencia<T>> adyacentes;

		public Nodo(T element) {
			distancia = INFINITO;
			this.element = element;
			cantidadDeAdyacencias = -1;
			adyacentes = new ListaArreglo<>();
		}

		public void agregarAdyacente(T destino, int peso) {
			if (cantidadDeAdyacencias == -1) {
				adyacentes.agregar(new Adyacencia<T>(destino, peso));
				cantidadDeAdyacencias++;
			} else {
				int pos;
				pos = darPosicionAdyacente(destino);
				if (pos == -1) {
					adyacentes.agregar(new Adyacencia<T>(destino, peso));
					cantidadDeAdyacencias++;
				}
			}

		}

		public int darPosicionAdyacente(T ady) {
			for (int i = 0; i < adyacentes.longitud(); i++) {
				Adyacencia<T> mio = null;
				mio = adyacentes.obtenerElemento(i);
				if (mio.adyacente.equals(ady))
					return i;
			}
			return -1;
		}

		public int darPesoAdyacente(int pos) {
			Adyacencia<T> ady = null;
			ady = adyacentes.obtenerElemento(pos);
			return ady.ponderacion;

		}

		public T darAdyacenteEnPos(int pos) {
			Adyacencia<T> m = null;
			m = adyacentes.obtenerElemento(pos);
			return m.adyacente;
		}

		public void eliminarAdyacencia(int pos) throws Exception {
			if (pos >= 0 && pos <= adyacentes.longitud()) {
				try {
					adyacentes.eliminar(pos);
				} catch (Exception e) {
					throw new Exception("No se puedo eliminar correctamente");
				}
				cantidadDeAdyacencias--;
			}
		}

		public T getElement() {
			return element;
		}

		public void setElement(T element) {
			this.element = element;
		}

		public int getDistancia() {
			return distancia;
		}

		public void setDistancia(int distancia) {
			this.distancia = distancia;
		}

		public int getCantidadDeAdyacencias() {
			return cantidadDeAdyacencias;
		}

		public void setCantidadDeAdyacencias(int enlaceExistente) {
			this.cantidadDeAdyacencias = enlaceExistente;
		}

		public ListaArreglo<Adyacencia<T>> getAdyacentes() {
			return adyacentes;
		}

		public void setAdyacentes(ListaArreglo<Adyacencia<T>> adyacentes) {
			this.adyacentes = adyacentes;
		}

	}

}