package GrahpMatrix;

public interface IMatriz<T> {

	public void agregarND(T vInicial, T vFinal, int peso);

	public void eliminarArista(T uno, T dos);

	public int[][] darMAtrizAdyacencia();

}
