package GrahpMatrix;

import java.util.ArrayList;

public class ListaArreglo<T> implements ILista<T> {

	protected ArrayList<T> contenedora;

	public ListaArreglo() {
		contenedora = new ArrayList<T>();
	}

	public boolean agregar(T elem) {
		boolean agregado = false;
		if (!contenedora.contains(elem)) {
			contenedora.add(elem);
			agregado = true;
		}
		return agregado;
	}

	public boolean agregarEnPos(int pos, T elem) {
		boolean agregado = false;
		if (!contenedora.contains(elem)) {
			contenedora.add(pos, elem);
			agregado = true;
		}
		return agregado;
	}

	@Override
	public boolean asignar(int pos, T elem) {
		if (!(pos > contenedora.size())) {
			contenedora.set(pos, elem);
			return true;
		} else {
			return false;
		}
	}

	public boolean eliminar(T elem) throws Exception {
		if (!contenedora.contains(elem)) {
			throw new Exception("No existe: " + elem);
		} else {
			contenedora.remove(buscar(elem));
		}
		return true;
	}

	@Override
	public T eliminar(int pos) throws Exception {
		T elemento = null;
		if (pos >= contenedora.size()) {
			throw new Exception("No existe: " + pos);
		} else {
			elemento = contenedora.remove(pos);
		}
		return elemento;
	}

	@Override
	public int longitud() {
		return contenedora.size();
	}

	@Override
	public boolean estaElemento(T elem) {
		return contenedora.contains(elem);
	}

	@Override
	public int buscar(T elem) throws Exception {
		int con = 0;
		boolean ya = false;
		if (!contenedora.contains(elem)) {
			throw new Exception("No existe: " + elem);
		} else {
			for (int i = 0; i < contenedora.size() && ya == false; i++) {
				if (elem.equals(contenedora.get(i))) {
					con = i;
					ya = true;
				}
			}
		}
		return con;
	}

	@Override
	public T obtenerElemento(int pos) {
		return contenedora.get(pos);
	}

	@Override
	public boolean estaVacia() {
		return contenedora.isEmpty();
	}

	@Override
	public boolean eliminarTodos() {
		contenedora.clear();
		return true;
	}
}
