package GrahpMatrix;

public interface IHerramientasGrafo<T> {

	public int[] DijkstraMatriz(MatrizAdyacencia<T> G, int ref);

	public void recorridoAmplitud(MatrizAdyacencia<T> G, Nodo<T> ref);

	public void recorridoProfundidad(MatrizAdyacencia<T> G, Nodo<T> ref);

	public int[][] FloydWarshall(MatrizAdyacencia<T> G);
}