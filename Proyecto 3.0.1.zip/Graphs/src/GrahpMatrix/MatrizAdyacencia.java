package GrahpMatrix;

import java.util.Hashtable;
import java.util.Iterator;

public class MatrizAdyacencia<T> implements IMatriz<T> {

	private HerramientasGrafo<T> otros;
	private int[][] adyacencias;
	private Hashtable<T, Nodo<T>> vertices;
	private Hashtable<T, Integer> elementos;
	private int cantidadNodos;
	private int tamanioMatriz;

	public MatrizAdyacencia(int tamanho) {
		otros = new HerramientasGrafo<>();
		tamanioMatriz = tamanho;
		adyacencias = new int[tamanioMatriz][tamanioMatriz];
		vertices = new Hashtable<>();
		elementos = new Hashtable<>();
	}

	public void agregarVertice(T nuevo1) {
		Nodo<T> nuevo = new Nodo<T>(nuevo1);
		if (!elementos.containsKey(nuevo1)) {
			elementos.put(nuevo1, cantidadNodos);
			vertices.put(nuevo1, nuevo);
			cantidadNodos++;
		}

	}

	public int darCantidadNodos() {
		return cantidadNodos;
	}

	@Override
	public int[][] darMAtrizAdyacencia() {
		for (Iterator<T> iterator = elementos.keySet().iterator(); iterator.hasNext();) {
			T type = (T) iterator.next();
			ListaArreglo<Adyacencia<T>> nodosAdyacentes = vertices.get(type).getAdyacentes();
			for (int j = 0; j < nodosAdyacentes.longitud(); j++) {
				int peso = nodosAdyacentes.obtenerElemento(j).getPonderacion();
				adyacencias[elementos.get(type)][elementos
						.get(nodosAdyacentes.obtenerElemento(j).getAdyacente())] = peso;
			}

		}
		return adyacencias;
	}

	@Override
	public void agregarND(T vInicial, T vFinal, int peso) {
		// TODO Auto-generated method stub
		vertices.get(vInicial).agregarAdyacente(vFinal, peso);
		vertices.get(vFinal).agregarAdyacente(vInicial, peso);
	}

	@Override
	public void eliminarArista(T uno, T dos) {
		// TODO Auto-generated method stub
		try {
			vertices.get(uno).eliminarAdyacencia(vertices.get(uno).darPosicionAdyacente(dos));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			vertices.get(dos).eliminarAdyacencia(vertices.get(dos).darPosicionAdyacente(uno));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public HerramientasGrafo<T> getOtros() {
		return otros;
	}

	public void setOtros(HerramientasGrafo<T> otros) {
		this.otros = otros;
	}

	public Hashtable<T, Integer> getElementos() {
		return elementos;
	}

	public void setElementos(Hashtable<T, Integer> elementos) {
		this.elementos = elementos;
	}

	public int[][] getAdyacencias() {
		return adyacencias;
	}

	public void setAdyacencias(int[][] adyacencias) {
		this.adyacencias = adyacencias;
	}

	public Hashtable<T, Nodo<T>> getVertices() {
		return vertices;
	}

	public void setVertices(Hashtable<T, Nodo<T>> vertices) {
		this.vertices = vertices;
	}

	public int getCantidadNodos() {
		return cantidadNodos;
	}

	public void setCantidadNodos(int cantidadNodos) {
		this.cantidadNodos = cantidadNodos;
	}

	public int getTamanioMatriz() {
		return tamanioMatriz;
	}

	public void setTamanioMatriz(int tamanioMatriz) {
		this.tamanioMatriz = tamanioMatriz;
	}
}
