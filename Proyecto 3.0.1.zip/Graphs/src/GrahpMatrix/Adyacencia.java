package GrahpMatrix;

public class Adyacencia<T> {
	protected T adyacente;
	protected int ponderacion;

	public Adyacencia(T ady, int p) {
		adyacente = ady;
		ponderacion = p;
	}

	public T getAdyacente() {
		return adyacente;
	}

	public void setAdyacente(T adyacente) {
		this.adyacente = adyacente;
	}

	public int getPonderacion() {
		return ponderacion;
	}

	public void setPonderacion(int ponderacion) {
		this.ponderacion = ponderacion;
	}

}
