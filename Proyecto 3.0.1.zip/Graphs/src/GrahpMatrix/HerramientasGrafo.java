package GrahpMatrix;

public class HerramientasGrafo<T> implements IHerramientasGrafo<T> {
	private int V;

	@Override
	public void recorridoAmplitud(MatrizAdyacencia<T> G, Nodo<T> ref) {
		// TODO Auto-generated method stub

	}

	@Override
	public void recorridoProfundidad(MatrizAdyacencia<T> G, Nodo<T> ref) {
		// TODO Auto-generated method stub

	}

	@Override
	public int[] DijkstraMatriz(MatrizAdyacencia<T> G, int ref) {
		int[][] Matrix = G.darMAtrizAdyacencia();
		V = Matrix.length;
		return Dijkstra(Matrix, ref, V);
	}

	private int[] Dijkstra(int graph[][], int src, int v1) {
		V = v1;
		int dist[] = new int[V]; // Matriz de distancias.
		Boolean sptSet[] = new Boolean[V]; // Matriz que indica si los nodos ya
											// fueron visitados.
		for (int i = 0; i < V; i++) {
			dist[i] = Integer.MAX_VALUE;
			sptSet[i] = false;
			// La distancia de los nodos cambia a infinito y visitado inicia en
			// false.
		}

		// Distancia desde el nodo actual.
		dist[src] = 0;

		// Encuentra la minima distancia de los vertices.
		for (int count = 0; count < V - 1; count++) {
			int u = minimaDistancia(dist, sptSet, V); // se toma la distancia
														// del
														// nodo actual a los
														// dem�s.
			sptSet[u] = true; // el nodo se marca como visitado
			for (int v = 0; v < V; v++)
				// La distancia del nodo actual a los adyacentes cambia.
				if (!sptSet[v] && graph[u][v] != 0 && dist[u] != Integer.MAX_VALUE && dist[u] + graph[u][v] < dist[v])
					dist[v] = dist[u] + graph[u][v];
		}

		// Devuelve el arreglo con las distancias m�s cortas.
		return dist;
	}

	private int minimaDistancia(int dist[], Boolean sptSet[], int v1) {
		V = v1;
		int min = Integer.MAX_VALUE, min_index = -1;

		for (int v = 0; v < V; v++)
			if (sptSet[v] == false && dist[v] <= min) {
				min = dist[v];
				min_index = v;
			}

		return min_index;
	}

	@Override
	public int[][] FloydWarshall(MatrizAdyacencia<T> G) {
		// TODO Auto-generated method stub
		int INFINITO = Integer.MAX_VALUE;
		int[][] Distancias = new int[G.darCantidadNodos()][G.darCantidadNodos()];
		int i, j, k;
		for (i = 0; i < G.darCantidadNodos(); i++) {
			for (j = 0; j < G.darCantidadNodos(); j++) {
				Distancias[i][j] = G.darMAtrizAdyacencia()[i][j];
				if ((i != j) && G.darMAtrizAdyacencia()[i][j] == 0)
					Distancias[i][j] = INFINITO;
			}
		}
		for (k = 0; k < G.darCantidadNodos(); k++) {
			for (i = 0; i < G.darCantidadNodos(); i++) {
				for (j = 0; j < G.darCantidadNodos(); j++) {
					if (Distancias[i][k] != INFINITO && Distancias[k][j] != INFINITO
							&& Distancias[i][k] + Distancias[k][j] < Distancias[i][j])
						Distancias[i][j] = Distancias[i][k] + Distancias[k][j];
				}

			}
		}

		return Distancias;
	}
}
