package Graph;

public class Nodo<T> {
	public final static int INFINITO = Integer.MAX_VALUE;
	protected T element;
	protected Nodo<T> padre;
	protected int distancia;
	protected int cantidadDeAdyacencias;
	protected boolean visitado;
	protected ListaArreglo<Adyacencia<T>> adyacentes;

	public Nodo(T element) {
		padre = null;
		distancia = INFINITO;
		visitado = false;
		this.element = element;
		cantidadDeAdyacencias = -1;
		adyacentes = new ListaArreglo<>();
	}

	public void agregarAdyacente(T destino, int peso) {
		if (cantidadDeAdyacencias == -1) {
			adyacentes.agregar(new Adyacencia<T>(destino, peso));
			cantidadDeAdyacencias++;
		} else {
			int pos;
			pos = darPosicionAdyacente(destino);
			if (pos == -1) {
				adyacentes.agregar(new Adyacencia<T>(destino, pos));
				cantidadDeAdyacencias++;
			}
		}

	}

	public int darPosicionAdyacente(T ady) {
		for (int i = 0; i < adyacentes.longitud(); i++) {
			Adyacencia<T> mio = null;
			mio = adyacentes.obtenerElemento(i);
			if (mio.adyacente.equals(ady))
				return i;
		}
		return -1;
	}

	public int darPesoAdyacente(int pos) {
		Adyacencia<T> ady = null;
		ady = adyacentes.obtenerElemento(pos);
		return ady.ponderacion;

	}

	public T darAdyacenteEnPos(int pos) {
		Adyacencia<T> m = null;
		m = adyacentes.obtenerElemento(pos);
		return m.adyacente;
	}

	public void eliminarAdyacencia(int pos) throws Exception {
		if (pos >= 0 && pos <= adyacentes.longitud()) {
			try {
				adyacentes.eliminar(pos);
			} catch (Exception e) {
				throw new Exception("No se puedo eliminar correctamente");
			}
			cantidadDeAdyacencias--;
		}
	}

	public T getElement() {
		return element;
	}

	public void setElement(T element) {
		this.element = element;
	}

	public int getDistancia() {
		return distancia;
	}

	public void setDistancia(int distancia) {
		this.distancia = distancia;
	}

	public int getCantidadDeAdyacencias() {
		return cantidadDeAdyacencias;
	}

	public void setCantidadDeAdyacencias(int enlaceExistente) {
		this.cantidadDeAdyacencias = enlaceExistente;
	}

	public ListaArreglo<Adyacencia<T>> getAdyacentes() {
		return adyacentes;
	}

	public void setAdyacentes(ListaArreglo<Adyacencia<T>> adyacentes) {
		this.adyacentes = adyacentes;
	}

	public boolean isVisitado() {
		return visitado;
	}

	public void setVisitado(boolean visitado) {
		this.visitado = visitado;
	}

	public Nodo<T> getPadre() {
		return padre;
	}

	public void setPadre(Nodo<T> padre) {
		this.padre = padre;
	}
}
