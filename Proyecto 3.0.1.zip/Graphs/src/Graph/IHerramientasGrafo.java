package Graph;

public interface IHerramientasGrafo<T> {

	public void Dijkstra(Grafo<T> G, Nodo<T> ref);

	public void recorridoAmplitud(Grafo<T> G, Nodo<T> ref);

	public void recorridoProfundidad(Grafo<T> G, Nodo<T> ref);
}