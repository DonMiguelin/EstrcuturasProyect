package Graph;

public interface IGrafo<T> {
	public void agregarVertice(T vertice);

	public void agregarND(T vInicial, T vFinal, int peso);

	public void eliminarArista(Arista<T> A);

}
