package Graph;

import java.util.PriorityQueue;

public class HerramientasGrafo<T> implements IHerramientasGrafo<T> {
	@Override
	public void Dijkstra(Grafo<T> G, Nodo<T> ref) {
		// TODO Auto-generated method stub
		int[] L = new int[G.getNodos().size()];
		PriorityQueue<T> C = new PriorityQueue<>();
		ref.setDistancia(0);
		L[G.getElementos().get(ref)] = 0;
		ref.setVisitado(false);
		ref.setPadre(null); 
		

	}

	@Override
	public void recorridoAmplitud(Grafo<T> G, Nodo<T> ref) {
		// TODO Auto-generated method stub

	}

	@Override
	public void recorridoProfundidad(Grafo<T> G, Nodo<T> ref) {
		// TODO Auto-generated method stub

	}

}
