package Graph;

public interface ILista<T> {

	public boolean agregar(T elem);

	public boolean asignar(int pos, T elem) throws Exception;

	public boolean eliminar(T elem) throws Exception;

	public T eliminar(int pos) throws Exception;

	public int longitud();

	public boolean estaElemento(T elem);

	public int buscar(T elem) throws Exception;

	public T obtenerElemento(int pos);

	public boolean estaVacia();

	public boolean eliminarTodos();

}
