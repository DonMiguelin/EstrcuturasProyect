package Graph;

import java.util.Dictionary;
import java.util.Hashtable;

public class Grafo<T> implements IGrafo<T> {
	private HerramientasGrafo<T> otros;
	private Hashtable<T, Integer> elementos;
	private ListaArreglo<Arista<T>> aristas;
	private Hashtable<T, Nodo<T>> nodos;
	private int cantidad;

	public Grafo() {
		cantidad = 0;
		elementos = new Hashtable<>();
		aristas = new ListaArreglo<>();
		nodos = new Hashtable<>();
		otros = new HerramientasGrafo<>();

	}

	@Override
	/**
	 * M�todo encargado de agregar un nodo.
	 */
	public void agregarVertice(T vertice) {
		// TODO Auto-generated method stub
		elementos.put(vertice, cantidad);
		nodos.put(vertice, new Nodo<T>(vertice));
		cantidad++;

	}

	@Override
	/**
	 * M�todo encargado de agregar nodos adyacentes (G es no dirigido).
	 */
	public void agregarND(T vInicial, T vFinal, int peso) {
		// TODO Auto-generated method stub
		Arista<T> a = new Arista<T>(vInicial, vFinal, peso);
		int i = buscarIndice(a.getPeso());
		if (i == -1)
			aristas.agregar(a);
		else
			aristas.agregarEnPos(i, a);
		nodos.get(vInicial).agregarAdyacente(vFinal, peso);
		nodos.get(vFinal).agregarAdyacente(vInicial, peso);

	}

	private int buscarIndice(int peso) {
		// TODO Auto-generated method stub
		for (int i = 0; i < aristas.longitud(); i++) {
			if (peso < aristas.obtenerElemento(i).peso)
				return i;
		}
		return -1;
	}

	@Override
	public void eliminarArista(Arista<T> A) {
		// TODO Auto-generated method stub
		for (int i = 0; i < aristas.longitud(); i++) {
			Arista<T> b = aristas.obtenerElemento(i);
			if (A.verticeInicial.equals(b.verticeInicial) && A.verticeFinal.equals(b.verticeFinal)
					&& A.peso == b.peso) {
				try {
					aristas.eliminar(b);
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
	}

	public Dictionary<T, Integer> getElementos() {
		return elementos;
	}

	public HerramientasGrafo<T> getOtros() {
		return otros;
	}

	public void setElementos(Hashtable<T, Integer> elementos) {
		this.elementos = elementos;
	}

	public ListaArreglo<Arista<T>> getAristas() {
		return aristas;
	}

	public void setAristas(ListaArreglo<Arista<T>> aristas) {
		this.aristas = aristas;
	}

	public Hashtable<T, Nodo<T>> getNodos() {
		return nodos;
	}

	public void setNodos(Hashtable<T, Nodo<T>> nodos) {
		this.nodos = nodos;
	}

}
