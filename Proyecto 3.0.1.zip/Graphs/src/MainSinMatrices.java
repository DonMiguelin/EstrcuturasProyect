import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.Queue;

import Graph.Grafo;

public class MainSinMatrices {
	private static Grafo<Integer> G;
	private static int[] policias;
	private static int[] bancos;
	private static Queue<int[]> Colac;

	public static void main(String[] args) throws IOException {
		BufferedReader lector = new BufferedReader(new InputStreamReader(System.in));
		BufferedWriter escritor = new BufferedWriter(new OutputStreamWriter(System.out));
		String linea = lector.readLine();
		while (linea != null && !linea.equals("")) {
			String[] datos = linea.split(" ");
			int[] data = new int[datos.length];
			for (int i = 0; i < datos.length; i++) {
				data[i] = Integer.parseInt(datos[i]);
			}
			int N = data[0];
			int M = data[1];
			int B = data[2];
			int P = data[3];
			G = new Grafo<>();
			bancos = new int[B];
			policias = new int[P];
			for (int i = 1; i <= M; i++) {
				linea = lector.readLine();
				String[] v = linea.split(" ");
				int vInicial = Integer.parseInt(v[0]);
				int vFinal = Integer.parseInt(v[1]);
				int peso = Integer.parseInt(v[2]);
				G.agregarVertice(vInicial);
				G.agregarVertice(vFinal);
				G.agregarND(vInicial, vFinal, peso);
			}
			linea = lector.readLine();
			String[] l = linea.split(" ");
			for (int i = 0; i < B; i++) {
				bancos[i] = Integer.parseInt(l[i]);
				G.agregarVertice(bancos[i]);
			}
			if (P != 0) {
				linea = lector.readLine();
				String[] p = linea.split(" ");
				for (int i = 0; i < P; i++) {
					policias[i] = Integer.parseInt(p[i]);
					G.agregarVertice(policias[i]);
				}
				// respuesta.
				// caminoMasCorto(G, bancos, escritor);
			}
			G = null;
			if (lector.ready()) {
				linea = lector.readLine();
			}
		}
		escritor.close();
	}

	// private static Queue<int[]> sacarPesos(int[] bancos, Grafo<Integer> g) {
	// Queue<int[]> C = new LinkedList<>();
	// for (int i = 0; i < bancos.length; i++) {
	// Nodo<Integer>ref= new Nodo<>(bancos[i]);
	// C.add(g.getOtros().Dijkstra(g, ref));
	// }
	// return C;
	// }

	// public static void caminoMasCorto(Grafo<Integer> g, int[] bancos,
	// BufferedWriter escritor)
	// throws IOException {
	// g = G;
	// int peso1 = 0;
	// int bPos = 0;
	// HashMap<Integer, Integer> tiempos = new HashMap<>();
	// Colac = new LinkedList<>();
	// Queue<int[]> Copia = new LinkedList<>();
	// Colac = sacarPesos(bancos, g);
	// Copia.addAll(Colac);
	// int[] tiempo2 = new int[Copia.size()];
	// while (!Copia.isEmpty()) {
	// for (int i = 0; i < policias.length; i++) {
	// peso1 += Copia.peek()[policias[i]];
	// }
	// tiempo2[bPos] = peso1;
	// tiempos.put(bancos[bPos], peso1);
	// peso1 = 0;
	// bPos++;
	// Copia.poll();
	// }
	// Arrays.sort(tiempo2);
	// int k = tiempo2[tiempo2.length - 1];
	// int[] listaBancosFinales = new int[G.getElementos().size()];
	// for (int i = 0; i < bancos.length; i++) {
	// if (k == tiempos.get(bancos[i])) {
	// listaBancosFinales[i] = bancos[i];
	// }
	// }
	// String b = "";
	// Arrays.sort(listaBancosFinales);
	// for (int i = 0; i < listaBancosFinales.length; i++) {
	// if (listaBancosFinales[i] != 0) {
	// if (i == listaBancosFinales.length - 1) {
	// b += listaBancosFinales[i];
	// } else
	// b += listaBancosFinales[i] + " ";
	// }
	// }
	// int respues = respuestaPeso(k, Colac);
	// if (respues != Integer.MAX_VALUE) {
	// escritor.write(b.split(" ").length + " " + respues);
	// escritor.newLine();
	// escritor.write(b);
	// escritor.newLine();
	// escritor.flush();
	//
	// } else {
	// escritor.write(b.split(" ").length + " " + "*");
	// escritor.newLine();
	// escritor.write(b);
	// escritor.newLine();
	// escritor.flush();
	// }
	// }

	private static int respuestaPeso(int k, Queue<int[]> Colac) {
		int peso = 0;
		int a = 0;
		int b = 0;
		while (!Colac.isEmpty()) {
			for (int i = 0; i < policias.length; i++) {
				peso += Colac.peek()[policias[i]];
			}
			if (k == peso) {
				b = Colac.peek()[policias[0]];
				for (int i = 1; i < policias.length; i++) {
					a = Colac.peek()[policias[i]];
					if (b > a)
						b = a;
				}
				break;
			}
			Colac.poll();
			peso = 0;
		}
		return b;
	}
}
