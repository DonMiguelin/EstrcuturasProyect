import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Queue;

public class Main3 {
	private static MatrizAdyacencia<Integer> G;
	private static int[] policias;
	private static int[] bancos;
	private static Queue<int[]> Colac;

	public static void main(String[] args) throws IOException {
		BufferedReader lector = new BufferedReader(new InputStreamReader(System.in));
		BufferedWriter escritor = new BufferedWriter(new OutputStreamWriter(System.out));
		String linea = lector.readLine();
		while (linea.split(" ").length == 4) {
			String[] datos = linea.split(" ");
			int[] data = new int[datos.length];
			for (int i = 0; i < datos.length; i++) {
				data[i] = Integer.parseInt(datos[i]);
			}
			int N = data[0];
			int M = data[1];
			int B = data[2];
			int P = data[3];
			G = new MatrizAdyacencia<>(N);
			bancos = new int[B];
			policias = new int[P];
			for (int i = 1; i <= M; i++) {
				linea = lector.readLine();
				String[] v = linea.split(" ");
				int vInicial = Integer.parseInt(v[0]);
				int vFinal = Integer.parseInt(v[1]);
				int peso = Integer.parseInt(v[2]);
				G.agregarVertice(vInicial);
				G.agregarVertice(vFinal);
				G.agregarND(vInicial, vFinal, peso);
			}
			linea = lector.readLine();
			String[] l = linea.split(" ");
			for (int i = 0; i < B; i++) {
				bancos[i] = Integer.parseInt(l[i]);
				G.agregarVertice(bancos[i]);
			}
			if (P != 0) {
				linea = lector.readLine();
				String[] p = linea.split(" ");
				for (int i = 0; i < P; i++) {
					policias[i] = Integer.parseInt(p[i]);
					G.agregarVertice(policias[i]);
				}
				// respuesta.
				caminoMasCorto(G, bancos, escritor);
			}
			G = null;
			if (lector.ready()) {
				linea = lector.readLine();
			}
		}
		escritor.close();
	}

	private static Queue<int[]> sacarPesos(int[] bancos, MatrizAdyacencia<Integer> g) {
		Queue<int[]> C = new LinkedList<>();
		for (int i = 0; i < bancos.length; i++) {
			C.add(g.getOtros().DijkstraMatriz(g, bancos[i]));
		}
		return C;
	}

	public static void caminoMasCorto(MatrizAdyacencia<Integer> g, int[] bancos, BufferedWriter escritor)
			throws IOException {
		g = G;
		int peso1 = 0;
		int bPos = 0;
		HashMap<Integer, Integer> tiempos = new HashMap<>();
		Colac = new LinkedList<>();
		Queue<int[]> Copia = new LinkedList<>();
		Colac = sacarPesos(bancos, g);
		Copia.addAll(Colac);
		int[] tiempo2 = new int[Copia.size()];
		while (!Copia.isEmpty()) {
			for (int i = 0; i < policias.length; i++) {
				peso1 += Copia.peek()[policias[i]];
			}
			tiempo2[bPos] = peso1;
			tiempos.put(bancos[bPos], peso1);
			peso1 = 0;
			bPos++;
			Copia.poll();
		}
		Arrays.sort(tiempo2);
		int k = tiempo2[tiempo2.length - 1];
		int[] listaBancosFinales = new int[G.getElementos().size()];
		for (int i = 0; i < bancos.length; i++) {
			if (k == tiempos.get(bancos[i])) {
				listaBancosFinales[i] = bancos[i];
			}
		}
		String b = "";
		Arrays.sort(listaBancosFinales);
		for (int i = 0; i < listaBancosFinales.length; i++) {
			if (listaBancosFinales[i] != 0) {
				if (i == listaBancosFinales.length - 1) {
					b += listaBancosFinales[i];
				} else
					b += listaBancosFinales[i] + " ";
			}
		}
		int respues = respuestaPeso(k, Colac);
		if (respues != Integer.MAX_VALUE) {
			escritor.write(b.split(" ").length + " " + respues);
			escritor.newLine();
			escritor.write(b);
			escritor.newLine();
			escritor.flush();

		} else {
			escritor.write(b.split(" ").length + " " + "*");
			escritor.newLine();
			escritor.write(b);
			escritor.newLine();
			escritor.flush();
		}
	}

	private static int respuestaPeso(int k, Queue<int[]> Colac) {
		int peso = 0;
		int a = 0;
		int b = 0;
		while (!Colac.isEmpty()) {
			for (int i = 0; i < policias.length; i++) {
				peso += Colac.peek()[policias[i]];
			}
			if (k == peso) {
				b = Colac.peek()[policias[0]];
				for (int i = 1; i < policias.length; i++) {
					a = Colac.peek()[policias[i]];
					if (b > a)
						b = a;
				}
				break;
			}
			Colac.poll();
			peso = 0;
		}
		return b;
	}

	public static class Adyacencia<T> {
		protected T adyacente;
		protected int ponderacion;

		public Adyacencia(T ady, int p) {
			adyacente = ady;
			ponderacion = p;
		}

		public T getAdyacente() {
			return adyacente;
		}

		public void setAdyacente(T adyacente) {
			this.adyacente = adyacente;
		}

		public int getPonderacion() {
			return ponderacion;
		}

		public void setPonderacion(int ponderacion) {
			this.ponderacion = ponderacion;
		}
	}

	public static class Arista<T> {
		protected T verticeInicial;
		protected T verticeFinal;
		protected int peso;

		public Arista(T inicio, T destino, int peso) {
			verticeInicial = inicio;
			verticeFinal = destino;
			this.peso = peso;
		}

		public T getVerticeInicial() {
			return verticeInicial;
		}

		public void setVerticeInicial(T verticeInicial) {
			this.verticeInicial = verticeInicial;
		}

		public T getVerticeFinal() {
			return verticeFinal;
		}

		public void setVerticeFinal(T verticeFinal) {
			this.verticeFinal = verticeFinal;
		}

		public int getPeso() {
			return peso;
		}

		public void setPeso(int peso) {
			this.peso = peso;
		}
	}

	public interface IHerramientasGrafo<T> {

		public int[] DijkstraMatriz(MatrizAdyacencia<T> G, int ref);

		public void recorridoAmplitud(MatrizAdyacencia<T> G, Nodo<T> ref);

		public void recorridoProfundidad(MatrizAdyacencia<T> G, Nodo<T> ref);
	}

	public static class HerramientasGrafo<T> implements IHerramientasGrafo<T> {
		private int V;

		@Override
		public void recorridoAmplitud(MatrizAdyacencia<T> G, Nodo<T> ref) {
			// TODO Auto-generated method stub

		}

		@Override
		public void recorridoProfundidad(MatrizAdyacencia<T> G, Nodo<T> ref) {
			// TODO Auto-generated method stub

		}

		@Override
		public int[] DijkstraMatriz(MatrizAdyacencia<T> G, int ref) {
			int[][] Matrix = G.darMAtrizAdyacencia();
			V = Matrix.length;
			return Dijkstra(Matrix, ref, V);
		}

		private int[] Dijkstra(int graph[][], int src, int v1) {
			V = v1;
			int dist[] = new int[V]; // Matriz de distancias.
			Boolean sptSet[] = new Boolean[V]; // Matriz que indica si los nodos
												// ya
												// fueron visitados.
			for (int i = 0; i < V; i++) {
				dist[i] = Integer.MAX_VALUE;
				sptSet[i] = false;
				// La distancia de los nodos cambia a infinito y visitado inicia
				// en
				// false.
			}

			// Distancia desde el nodo actual.
			dist[src] = 0;

			// Encuentra la minima distancia de los vertices.
			for (int count = 0; count < V - 1; count++) {
				int u = minimaDistancia(dist, sptSet, V); // se toma la
															// distancia
															// del
															// nodo actual a los
															// dem�s.
				sptSet[u] = true; // el nodo se marca como visitado
				for (int v = 0; v < V; v++)
					// La distancia del nodo actual a los adyacentes cambia.
					if (!sptSet[v] && graph[u][v] != 0 && dist[u] != Integer.MAX_VALUE
							&& dist[u] + graph[u][v] < dist[v])
						dist[v] = dist[u] + graph[u][v];
			}

			// Devuelve el arreglo con las distancias m�s cortas.
			return dist;
		}

		private int minimaDistancia(int dist[], Boolean sptSet[], int v1) {
			V = v1;
			int min = Integer.MAX_VALUE, min_index = -1;

			for (int v = 0; v < V; v++)
				if (sptSet[v] == false && dist[v] <= min) {
					min = dist[v];
					min_index = v;
				}

			return min_index;
		}
	}

	public interface ILista<T> {

		public boolean agregar(T elem);

		public boolean asignar(int pos, T elem) throws Exception;

		public boolean eliminar(T elem) throws Exception;

		public T eliminar(int pos) throws Exception;

		public int longitud();

		public boolean estaElemento(T elem);

		public int buscar(T elem) throws Exception;

		public T obtenerElemento(int pos);

		public boolean estaVacia();

		public boolean eliminarTodos();

	}

	public interface IMatriz<T> {

		public void agregarND(T vInicial, T vFinal, int peso);

		public void eliminarArista(Arista<T> A);

	}

	public static class ListaArreglo<T> implements ILista<T> {

		protected ArrayList<T> contenedora;

		public ListaArreglo() {
			contenedora = new ArrayList<T>();
		}

		public boolean agregar(T elem) {
			boolean agregado = false;
			if (!contenedora.contains(elem)) {
				contenedora.add(elem);
				agregado = true;
			}
			return agregado;
		}

		public boolean agregarEnPos(int pos, T elem) {
			boolean agregado = false;
			if (!contenedora.contains(elem)) {
				contenedora.add(pos, elem);
				agregado = true;
			}
			return agregado;
		}

		@Override
		public boolean asignar(int pos, T elem) {
			if (!(pos > contenedora.size())) {
				contenedora.set(pos, elem);
				return true;
			} else {
				return false;
			}
		}

		public boolean eliminar(T elem) throws Exception {
			if (!contenedora.contains(elem)) {
				throw new Exception("No existe: " + elem);
			} else {
				contenedora.remove(buscar(elem));
			}
			return true;
		}

		@Override
		public T eliminar(int pos) throws Exception {
			T elemento = null;
			if (pos >= contenedora.size()) {
				throw new Exception("No existe: " + pos);
			} else {
				elemento = contenedora.remove(pos);
			}
			return elemento;
		}

		@Override
		public int longitud() {
			return contenedora.size();
		}

		@Override
		public boolean estaElemento(T elem) {
			return contenedora.contains(elem);
		}

		@Override
		public int buscar(T elem) throws Exception {
			int con = 0;
			boolean ya = false;
			if (!contenedora.contains(elem)) {
				throw new Exception("No existe: " + elem);
			} else {
				for (int i = 0; i < contenedora.size() && ya == false; i++) {
					if (elem.equals(contenedora.get(i))) {
						con = i;
						ya = true;
					}
				}
			}
			return con;
		}

		@Override
		public T obtenerElemento(int pos) {
			return contenedora.get(pos);
		}

		@Override
		public boolean estaVacia() {
			return contenedora.isEmpty();
		}

		@Override
		public boolean eliminarTodos() {
			contenedora.clear();
			return true;
		}
	}

	public static class MatrizAdyacencia<T> implements IMatriz<T> {

		private HerramientasGrafo<T> otros;
		private int[][] adyacencias;
		private Hashtable<T, Nodo<T>> vertices;
		private ListaArreglo<Arista<T>> aristas;
		private Hashtable<T, Integer> elementos;
		private int cantidadNodos;
		private int tamanioMatriz;

		public MatrizAdyacencia(int tamanho) {
			otros = new HerramientasGrafo<>();
			tamanioMatriz = tamanho;
			adyacencias = new int[tamanioMatriz][tamanioMatriz];
			vertices = new Hashtable<>();
			elementos = new Hashtable<>();
			aristas = new ListaArreglo<>();
		}

		public void agregarVertice(T nuevo1) {
			Nodo<T> nuevo = new Nodo<T>(nuevo1);
			if (!elementos.containsKey(nuevo1)) {
				elementos.put(nuevo1, cantidadNodos);
				vertices.put(nuevo1, nuevo);
				cantidadNodos++;
			}

		}

		public int darCantidadNodos() {
			return cantidadNodos;
		}

		public int[][] darMAtrizAdyacencia() {
			for (Iterator<T> iterator = elementos.keySet().iterator(); iterator.hasNext();) {
				T type = (T) iterator.next();
				ListaArreglo<Adyacencia<T>> nodosAdyacentes = vertices.get(type).getAdyacentes();
				for (int j = 0; j < nodosAdyacentes.longitud(); j++) {
					int peso = nodosAdyacentes.obtenerElemento(j).getPonderacion();
					adyacencias[elementos.get(type)][elementos
							.get(nodosAdyacentes.obtenerElemento(j).getAdyacente())] = peso;
				}

			}
			return adyacencias;
		}

		@Override
		public void agregarND(T vInicial, T vFinal, int peso) {
			// TODO Auto-generated method stub
			Arista<T> nuevo = new Arista<T>(vInicial, vFinal, peso);
			aristas.agregar(nuevo);
			vertices.get(vInicial).agregarAdyacente(vFinal, peso);
			vertices.get(vFinal).agregarAdyacente(vInicial, peso);
		}

		@Override
		public void eliminarArista(Arista<T> A) {
			// TODO Auto-generated method stub
			T uno = A.getVerticeInicial();
			T dos = A.getVerticeFinal();
			try {
				aristas.eliminar(A);
			} catch (Exception e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			try {
				vertices.get(uno).eliminarAdyacencia(vertices.get(uno).darPosicionAdyacente(dos));
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			try {
				vertices.get(dos).eliminarAdyacencia(vertices.get(dos).darPosicionAdyacente(uno));
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}

		public HerramientasGrafo<T> getOtros() {
			return otros;
		}

		public void setOtros(HerramientasGrafo<T> otros) {
			this.otros = otros;
		}

		public ListaArreglo<Arista<T>> getAristas() {
			return aristas;
		}

		public void setAristas(ListaArreglo<Arista<T>> aristas) {
			this.aristas = aristas;
		}

		public Hashtable<T, Integer> getElementos() {
			return elementos;
		}

		public void setElementos(Hashtable<T, Integer> elementos) {
			this.elementos = elementos;
		}

		public int[][] getAdyacencias() {
			return adyacencias;
		}

		public void setAdyacencias(int[][] adyacencias) {
			this.adyacencias = adyacencias;
		}

		public Hashtable<T, Nodo<T>> getVertices() {
			return vertices;
		}

		public void setVertices(Hashtable<T, Nodo<T>> vertices) {
			this.vertices = vertices;
		}

		public int getCantidadNodos() {
			return cantidadNodos;
		}

		public void setCantidadNodos(int cantidadNodos) {
			this.cantidadNodos = cantidadNodos;
		}

		public int getTamanioMatriz() {
			return tamanioMatriz;
		}

		public void setTamanioMatriz(int tamanioMatriz) {
			this.tamanioMatriz = tamanioMatriz;
		}
	}

	public static class Nodo<T> {
		public final static int BLACK = 0;
		public final static int GRAY = 1;
		public final static int WHITE = 2;
		public final static int INFINITO = Integer.MAX_VALUE;
		protected T element;
		protected Nodo<T> pi;
		protected int color;
		protected int distancia;
		protected int cantidadDeAdyacencias;
		protected ListaArreglo<Adyacencia<T>> adyacentes;

		public Nodo(T element) {
			pi = null;
			distancia = INFINITO;
			color = WHITE;
			this.element = element;
			cantidadDeAdyacencias = -1;
			adyacentes = new ListaArreglo<>();
		}

		public void agregarAdyacente(T destino, int peso) {
			if (cantidadDeAdyacencias == -1) {
				adyacentes.agregar(new Adyacencia<T>(destino, peso));
				cantidadDeAdyacencias++;
			} else {
				int pos;
				pos = darPosicionAdyacente(destino);
				if (pos == -1) {
					adyacentes.agregar(new Adyacencia<T>(destino, peso));
					cantidadDeAdyacencias++;
				}
			}

		}

		public int darPosicionAdyacente(T ady) {
			for (int i = 0; i < adyacentes.longitud(); i++) {
				Adyacencia<T> mio = null;
				mio = adyacentes.obtenerElemento(i);
				if (mio.adyacente.equals(ady))
					return i;
			}
			return -1;
		}

		public int darPesoAdyacente(int pos) {
			Adyacencia<T> ady = null;
			ady = adyacentes.obtenerElemento(pos);
			return ady.ponderacion;

		}

		public T darAdyacenteEnPos(int pos) {
			Adyacencia<T> m = null;
			m = adyacentes.obtenerElemento(pos);
			return m.adyacente;
		}

		public void eliminarAdyacencia(int pos) throws Exception {
			if (pos >= 0 && pos <= adyacentes.longitud()) {
				try {
					adyacentes.eliminar(pos);
				} catch (Exception e) {
					throw new Exception("No se puedo eliminar correctamente");
				}
				cantidadDeAdyacencias--;
			}
		}

		public T getElement() {
			return element;
		}

		public void setElement(T element) {
			this.element = element;
		}

		public Nodo<T> getPi() {
			return pi;
		}

		public void setPi(Nodo<T> pi) {
			this.pi = pi;
		}

		public int getColor() {
			return color;
		}

		public void setColor(int color) {
			this.color = color;
		}

		public int getDistancia() {
			return distancia;
		}

		public void setDistancia(int distancia) {
			this.distancia = distancia;
		}

		public int getCantidadDeAdyacencias() {
			return cantidadDeAdyacencias;
		}

		public void setCantidadDeAdyacencias(int enlaceExistente) {
			this.cantidadDeAdyacencias = enlaceExistente;
		}

		public ListaArreglo<Adyacencia<T>> getAdyacentes() {
			return adyacentes;
		}

		public void setAdyacentes(ListaArreglo<Adyacencia<T>> adyacentes) {
			this.adyacentes = adyacentes;
		}
	}
}
