import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.Arrays;
import java.util.HashMap;
import java.util.PriorityQueue;
import java.util.Queue;

import GrahpMatrix.MatrizAdyacencia;

public class MainFLoydWarshall {
	private static MatrizAdyacencia<Integer> G;
	private static int p1;
	private static int p2;
	private static int[] policias;
	private static int[] bancos;
	private static HashMap<Integer, Queue<Integer>> pesos;

	public static void main(String[] args) throws IOException {
		BufferedReader lector = new BufferedReader(new InputStreamReader(System.in));
		BufferedWriter escritor = new BufferedWriter(new OutputStreamWriter(System.out));
		String linea = lector.readLine();
		while (linea.split(" ").length == 4) {
			String[] datos = linea.split(" ");
			int[] data = new int[datos.length];
			for (int i = 0; i < datos.length; i++) {
				data[i] = Integer.parseInt(datos[i]);
			}
			int N = data[0];
			int M = data[1];
			int B = data[2];
			int P = data[3];
			G = new MatrizAdyacencia<>(N);
			bancos = new int[B];
			policias = new int[P];
			for (int i = 1; i <= M; i++) {
				linea = lector.readLine();
				String[] v = linea.split(" ");
				int vInicial = Integer.parseInt(v[0]);
				int vFinal = Integer.parseInt(v[1]);
				int peso = Integer.parseInt(v[2]);
				G.agregarVertice(vInicial);
				G.agregarVertice(vFinal);
				G.agregarND(vInicial, vFinal, peso);
			}
			linea = lector.readLine();
			String[] l = linea.split(" ");
			for (int i = 0; i < B; i++) {
				bancos[i] = Integer.parseInt(l[i]);
				G.agregarVertice(bancos[i]);
			}
			if (P != 0) {
				linea = lector.readLine();
				String[] p = linea.split(" ");
				for (int i = 0; i < P; i++) {
					policias[i] = Integer.parseInt(p[i]);
					G.agregarVertice(policias[i]);
				}
				// respuesta.
				caminoMasCorto(G, bancos, policias, escritor);
			}
			G = null;
			if (lector.ready()) {
				linea = lector.readLine();
			}

		}
		escritor.close();
	}

	private static String bancosFinales(int[] bancos, int[] policias, MatrizAdyacencia<Integer> g) {
		int[][] Emergente = g.getOtros().FloydWarshall(g);
		distanciasBancosPolicias(Emergente);
		String listaDebancos = "";
		int p3, p4;
		String m = "";
		m = maximoYminimo(pesos, bancos[0]);
		int pos = 0;
		p1 = Integer.parseInt(m.split(" ")[0]);// maximo
		p2 = Integer.parseInt(m.split(" ")[1]);// minimo
		for (int i = 0; i < bancos.length - 1; i++) {
			m = maximoYminimo(pesos, bancos[i + 1]);
			p3 = Integer.parseInt(m.split(" ")[0]);// maximo
			p4 = Integer.parseInt(m.split(" ")[1]);// minimo
			if (p2 == p4 && p3 == p1) {
				if (!listaDebancos.contains("" + bancos[pos])) {
					listaDebancos += bancos[i] + " ";
					pos++;
				}
				if (!listaDebancos.contains("" + bancos[i + 1])) {
					listaDebancos += bancos[i + 1] + " ";
				}
			} else {
				if (p1 == p3) {
					if (p2 < p4) {
						p2 = p4;
						if (!listaDebancos.contains("" + bancos[i + 1])) {
							listaDebancos = bancos[i + 1] + " ";
							pos++;

						}
					} else {
						if (!listaDebancos.contains("" + bancos[pos])) {
							listaDebancos = bancos[pos] + " ";
						}

					}

				} else {
					if (p1 < p3) {
						p1 = p3;
						p2 = p4;
						if (!listaDebancos.contains("" + bancos[i + 1])) {
							listaDebancos = bancos[i + 1] + " ";
							pos++;
						}
					} else {
						if (!listaDebancos.contains("" + bancos[pos]))
							listaDebancos = bancos[pos] + " ";
					}
				}
			}
		}

		return listaDebancos;
	}

	public static void caminoMasCorto(MatrizAdyacencia<Integer> g, int[] bancos, int[] policias,
			BufferedWriter escritor) throws IOException {
		g = G;
		String[] A = bancosFinales(bancos, policias, g).split(" ");
		Arrays.sort(A);
		String b = "";
		for (int i = 0; i < A.length; i++) {
			if (i == A.length - 1) {
				b += A[i] + "";
			} else
				b += A[i] + " ";
		}
		int respuesta = p1;
		if (respuesta != Integer.MAX_VALUE) {
			escritor.write(A.length + " " + respuesta);
			escritor.newLine();
			escritor.write(b);
			escritor.newLine();
			escritor.flush();

		} else {
			escritor.write(A.length + " " + "*");
			escritor.newLine();
			escritor.write(b);
			escritor.newLine();
			escritor.flush();
		}
	}

	private static void distanciasBancosPolicias(int[][] matriz) {
		pesos = new HashMap<>();
		for (int i = 0; i < bancos.length; i++) {
			Queue<Integer> priori = new PriorityQueue<>();
			for (int j = 0; j < policias.length; j++) {
				priori.add(matriz[G.getElementos().get(bancos[i])][G.getElementos().get(policias[j])]);
			}
			pesos.put(bancos[i], priori);
		}
	}

	private static String maximoYminimo(HashMap<Integer, Queue<Integer>> distancias, int banco) {
		String maxmin = "";
		Queue<Integer> distance = distancias.get(banco);
		int max, min;
		min = distance.peek();
		max = min;
		max = (int) distance.toArray()[distance.size() - 1];
		maxmin = max + " " + min;
		return maxmin;

	}
}